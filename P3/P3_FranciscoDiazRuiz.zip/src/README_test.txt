Per executar el codi de prova sense la necessitat de passar per cadascuna de les opcions es pot 
fer de la seguent manera:

- Primer compilem els fitxers .c cridant al make 
- Seguidament fem: valgrind ./main <test 

fent aquesta canonada de test on hi han les diferents opcions que es posaran quan es demani al usuari
que entri una opcio per teclat i d'aquesta manera es mes facil provar el programa.
